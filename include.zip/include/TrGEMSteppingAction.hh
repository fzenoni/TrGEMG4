#ifndef TrGEMSteppingAction_h
#define TrGEMSteppingAction_h 1

#include "G4UserSteppingAction.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class TrGEMSteppingAction : public G4UserSteppingAction
{
   public:
      TrGEMSteppingAction();
      ~TrGEMSteppingAction(){};

      void UserSteppingAction(const G4Step*);

};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif
